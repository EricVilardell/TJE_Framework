Xia Zhang  xia.zhang01@estudiant.upf.edu 253878
Eric Vilardell eric.vilardell01@estudiant.upf.edu 254469

Audio Eric
UI Xia
Player control Xia
Audio Eric
Collisions Xia
Aesthetics Eric